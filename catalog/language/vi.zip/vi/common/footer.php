<?php
// Text
$_['text_information']  = 'Thông tin';
$_['text_service']      = 'Chăm sóc khách hàng';
$_['text_extra']        = 'Tiện ích';
$_['text_contact']      = 'Liên hệ';
$_['text_return']       = 'Quay lại';
$_['text_sitemap']      = 'Bản đồ site';
$_['text_manufacturer'] = 'Thương hiệu';
$_['text_voucher']      = 'Quà tặng';
$_['text_affiliate']    = 'Liên kết';
$_['text_special']      = 'Sản phẩm đặc biệt';
$_['text_account']      = 'Tài khoản của tôi';
$_['text_order']        = 'Lược sử mua hàng';
$_['text_wishlist']     = 'Yêu thích';
$_['text_newsletter']   = 'Tin tức';
$_['text_powered']      = 'Mã nguồn <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';