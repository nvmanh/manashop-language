<?php
// Text
$_['text_all'] = 'Hiện tất cả';