<?php
// Text
$_['text_currency'] = 'Loại tiền';