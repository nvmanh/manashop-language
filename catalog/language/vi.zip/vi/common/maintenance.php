<?php
// Heading
$_['heading_title']    = 'Bảo trì';

// Text
$_['text_maintenance'] = 'Bảo trì';
$_['text_message']     = '<h1 style="text-align:center;">Trang web đang trong quá trình bảo trì định kỳ. <br/>Chúng tôi sẽ trở lại ngay. Bạn thử lại sau ít phút nữa nhé.</h1>';