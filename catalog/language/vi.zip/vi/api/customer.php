<?php
// Text
$_['text_success']       = 'Bạn vừa cập nhật khách hàng';

// Error
$_['error_permission']   = 'Cảnh báo: Bạn không có quyền truy cập vào API!';
$_['error_customer']     = 'Bạn phải chọn một khách hàng';
$_['error_firstname']    = 'Họ và tên đệm phải dài từ 1 đến 32 ký tự!';
$_['error_lastname']     = 'Tên phải dài từ 1 đến 32 ký tự!';
$_['error_email']        = 'E-Mail không hợp lệ!';
$_['error_telephone']    = 'SĐT phải dài từ 3 đến 32 ký tự!';
$_['error_custom_field'] = '%s bắt buộc!';