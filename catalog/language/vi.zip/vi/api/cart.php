<?php
// Text
$_['text_success']     = 'Thành công: Bạn vừa cập nhật giỏ hàng!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào API!';
$_['error_stock']      = 'Những sản phẩm được đánh dâu *** hiện đã hết hàng hoặc chưa nhập!';
$_['error_minimum']    = 'Số đơn hàng nhỏ nhất với %s là %s!';
$_['error_store']      = 'Sản phẩm mà bạn chọn không thể mua!';
$_['error_required']   = '%s bắt buộc!';