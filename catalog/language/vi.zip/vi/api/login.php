<?php
// Text
$_['text_success'] = 'Thành công: phiên dùng API bắt đầu thành công!';

// Error
$_['error_key']    = 'Cảnh báo: Không đúng khóa API!';
$_['error_ip']     = 'Cảnh báo: Địa chỉ IP %s không được phép truy cập API!';