<?php
// Text
$_['text_success']     = 'Thành công: Coupon giảm gía đã được dùng!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào API!';
$_['error_coupon']     = 'Cảnh báo: Coupon không hợp lệ, hệt hạn hoặc đã được dùng hết!';