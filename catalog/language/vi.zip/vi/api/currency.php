<?php
// Text
$_['text_success']     = 'Thành công: Loại tiền đã được thay đổi!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào API!';
$_['error_currency']   = 'Cảnh báo: Loai tiền không hợp lệ!';