<?php
// Text
$_['text_success']     = 'Thành công: Điểm thưởng của bạn đã được áp dụng!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào API!';
$_['error_reward']     = 'Cảnh báo: Bạn phải nhập số điểm thưởng muốn dùng!';
$_['error_points']     = 'Cảnh báo: Bạn thiếu %s điểm thưởng!';
$_['error_maximum']    = 'Cảnh báo: Số điểm thưởng tối đa bạn có thể dùng là %s!';