<?php
// Heading
$_['heading_title']  = 'Reset mật khẩu';

// Text
$_['text_account']   = 'Tài khoản';
$_['text_password']  = 'Nhập mật khẩu mới.';
$_['text_success']   = 'Thành công: Mật khẩu của bạn đã được đổi.';

// Entry
$_['entry_password'] = 'Mật khẩu';
$_['entry_confirm']  = 'Xác nhận';

// Error
$_['error_password'] = 'Mật khẩu phải dài từ 4 đến 20 ký tự!';
$_['error_confirm']  = 'Xác nhận mật khẩu không giống!';
$_['error_code']     = 'Mã reset mật  khẩu không hợp lệ hoặc đã được dùng!';