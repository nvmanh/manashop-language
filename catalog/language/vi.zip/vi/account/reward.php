<?php
// Heading
$_['heading_title']      = 'Điểm thưởng';

// Column
$_['column_date_added']  = 'Ngày cập nhật';
$_['column_description'] = 'Mô tả';
$_['column_points']      = 'Điểm';

// Text
$_['text_account']       = 'Tài khoản';
$_['text_reward']        = 'Điểm thưởng';
$_['text_total']         = 'Tổng điểm của bạn là:';
$_['text_empty']         = 'Bạn chưa có điểm thưởng nào!';