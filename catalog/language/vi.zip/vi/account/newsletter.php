<?php
// Heading
$_['heading_title']    = 'Đăng ký nhận tin';

// Text
$_['text_account']     = 'Tài khoản';
$_['text_newsletter']  = 'Tin tức';
$_['text_success']     = 'Thành công: Bạn đã đăng ký nhận tin thành công!';

// Entry
$_['entry_newsletter'] = 'Đăng ký tin';