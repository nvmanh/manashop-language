<?php
// Heading
$_['heading_title']      = 'Giao dịch';

// Column
$_['column_date_added']  = 'Ngày tạo';
$_['column_description'] = 'Mô tả';
$_['column_amount']      = 'Tổng tiền (%s)';

// Text
$_['text_account']       = 'Tài khoản';
$_['text_transaction']   = 'Giao dịch của bạn';
$_['text_total']         = 'Số dư của bạn hiện tại là:';
$_['text_empty']         = 'Bạn chưa thực hiện giao dịch nào cả!';