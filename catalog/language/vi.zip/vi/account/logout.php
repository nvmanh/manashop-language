<?php
// Heading
$_['heading_title'] = 'Đăng xuất';

// Text
$_['text_message']  = '<p>Bạn đã đăng xuất tài khoản. Mọi thông tin cache đã được xóa.</p><p>Giỏ hàng đã được lưu lại, và các sản phẩm trong đó được gĩư nguyên cho tới khi bạn đăng nhập lại.</p>';
$_['text_account']  = 'Tài khoản';
$_['text_logout']   = 'Đăng xuất';