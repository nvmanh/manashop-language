<?php
// Heading
$_['heading_title']     = 'Tải về';

// Text
$_['text_account']      = 'Tài khoản';
$_['text_downloads']    = 'Tải về';
$_['text_empty']        = 'Bạn không có đơn hàng nào để tải về!';

// Column
$_['column_order_id']   = 'Mã đơn hàng';
$_['column_name']       = 'Tên';
$_['column_size']       = 'Kích thước';
$_['column_date_added'] = 'Ngày tạo';