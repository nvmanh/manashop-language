<?php
// Heading
$_['heading_title']    = 'Theo dõi liên kết';

// Text
$_['text_account']     = 'Tài khoản';
$_['text_description'] = 'Để đảm bảo rằng bạn đã nhận được điểm thưởng từ việc giới thiệu liên kết bạn cần gửi cho chúng tôi link địa chỉ mà bạn đã đặt liên kết. Bạn có thể dùng công cụ bên dưới để tạo liên kết %s web site.';

// Entry
$_['entry_code']       = 'Mã theo dõi của bạn';
$_['entry_generator']  = 'Tạo liên kết theo dõi';
$_['entry_link']       = 'Liên kết theo dõi';

// Help
$_['help_generator']  = 'Nhập tên sản phẩm mà bạn muốn link tới';