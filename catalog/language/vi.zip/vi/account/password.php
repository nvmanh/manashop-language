<?php
// Heading
$_['heading_title']  = 'Đổi mật khẩu';

// Text
$_['text_account']   = 'Tài khoản';
$_['text_password']  = 'Mật khẩu';
$_['text_success']   = 'Thành công: Mật khẩu của bạn được cập nhật thành công.';

// Entry
$_['entry_password'] = 'Mật khẩu';
$_['entry_confirm']  = 'Xác nhận mật khẩu';

// Error
$_['error_password'] = 'Mật khẩu dài 4 đến 20 ký tự!';
$_['error_confirm']  = 'Mật khẩu xác nhận không giống!';