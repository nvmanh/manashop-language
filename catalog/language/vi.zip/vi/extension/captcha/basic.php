<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'Hãy nhập mã vào ô bên dưới';

// Error
$_['error_captcha'] = 'Mã nhập không khớp với hình!';