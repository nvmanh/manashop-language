<?php
// Heading
$_['heading_title'] = 'Mã Coupon';

// Text
$_['text_coupon']   = 'Coupon (%s)';
$_['text_success']  = 'Thành công: Mã coupon giảm gía đã được áp dụng!';

// Entry
$_['entry_coupon']  = 'Nhập mã coupon ở đây';

// Error
$_['error_coupon']  = 'Cảnh báo: Coupon không hợp lệ, hết hạn hoặc đã được dùng!';
$_['error_empty']   = 'Cảnh báo: Hãy nhập một mã coupon!';