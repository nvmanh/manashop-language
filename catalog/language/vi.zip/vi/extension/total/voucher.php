<?php
// Heading
$_['heading_title'] = 'Sử dụng mã quà tặng voucher';

// Text
$_['text_voucher']  = 'Mã quà tặng (%s)';
$_['text_success']  = 'Thành công: Mã quà tặng giảm gía đã được áp dụng!';

// Entry
$_['entry_voucher'] = 'Hãy nhập mã quà tặng ở đây';

// Error
$_['error_voucher'] = 'Cảnh báo: Mã quà tặng không hợp lệ!';
$_['error_empty']   = 'Cảnh báo: Hãy nhập một mã quà tặng!';