<?php
// Text
$_['text_total'] = 'Tổng';