<?php
// Heading
$_['heading_title'] = 'Thông tin';

// Text
$_['text_contact']  = 'Liên hệ với shop';
$_['text_sitemap']  = 'Bản đồ website';