<?php
// Heading
$_['heading_title']    = 'Tài khoản';

// Text
$_['text_register']    = 'Đăng ký';
$_['text_login']       = 'Đăng nhập';
$_['text_logout']      = 'Đăng xuất';
$_['text_forgotten']   = 'Quên mật khẩu';
$_['text_account']     = 'Tài khoản';
$_['text_edit']        = 'Cập nhật tài khoản';
$_['text_password']    = 'Mật khẩu';
$_['text_address']     = 'Sổ địa chỉ';
$_['text_wishlist']    = 'Yêu thích';
$_['text_order']       = 'Lược sử đặt hàng';
$_['text_download']    = 'Tải tài liệu';
$_['text_reward']      = 'Điểm thưởng';
$_['text_return']      = 'Hoàn trả hàng';
$_['text_transaction'] = 'Giao dịch';
$_['text_newsletter']  = 'Tint tức';
$_['text_recurring']   = 'Thanh toán định kỳ';