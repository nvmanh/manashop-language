<?php
// Heading
$_['heading_title'] = 'Bán chạy';

// Text
$_['text_tax']      = 'Thuế:';