<?php
// Heading
$_['heading_title'] = 'Nổi bật';

// Text
$_['text_tax']      = 'Thuế:';