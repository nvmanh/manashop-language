<?php
// Calculator
$_['text_checkout_title']      = 'Trả định kỳ';
$_['text_choose_plan']         = 'Chọn kế hoạch';
$_['text_choose_deposit']      = 'Chọn phương thức';
$_['text_monthly_payments']    = 'khoản trả hàng tháng';
$_['text_months']              = 'tháng';
$_['text_term']                = 'Điều khoản';
$_['text_deposit']             = 'Nợ';
$_['text_credit_amount']       = 'Tiền';
$_['text_amount_payable']      = 'Tổng trả';
$_['text_total_interest']      = 'Tổng APR';
$_['text_monthly_installment'] = 'Thanh toán hàng tháng';
$_['text_redirection']         = 'Bạn sẽ được chuyển tới Divido và hoàn thiện thông tin để thanh toán đơn hàng';