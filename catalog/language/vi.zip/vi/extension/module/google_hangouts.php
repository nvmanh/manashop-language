<?php
// Heading
$_['heading_title'] = 'Chat trực tuyến';