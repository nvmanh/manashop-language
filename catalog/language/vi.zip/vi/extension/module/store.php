<?php
// Heading
$_['heading_title'] = 'Chọn một cửa hàng';

// Text
$_['text_default']  = 'Mặc định';
$_['text_store']    = 'Hãy chọn gian hàng mà bạn muốn đến.';