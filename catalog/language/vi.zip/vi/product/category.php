<?php
// Text
$_['text_refine']       = 'Tinh chỉnh tìm kiếm';
$_['text_product']      = 'Sản phẩm';
$_['text_error']        = 'Danh mục không tồn tại!';
$_['text_empty']        = 'Không có sản phẩm trong danh mục này.';
$_['text_quantity']     = 'Số lượng:';
$_['text_manufacturer'] = 'Nhà sản xuất:';
$_['text_model']        = 'Mã sản phẩm:';
$_['text_points']       = 'Điểmt hưởng:';
$_['text_price']        = 'Gía:';
$_['text_tax']          = 'Thuế:';
$_['text_compare']      = 'Sản phẩm so sánh (%s)';
$_['text_sort']         = 'Sắp xếp theo:';
$_['text_default']      = 'Mặc định';
$_['text_name_asc']     = 'Tên (A - Z)';
$_['text_name_desc']    = 'Tên (Z - A)';
$_['text_price_asc']    = 'Gía (Thâp &gt; Cao)';
$_['text_price_desc']   = 'Gía (Cao &gt; Thấp)';
$_['text_rating_asc']   = 'Đánh gía (Thấp nhất)';
$_['text_rating_desc']  = 'Đánh gía (Cao nhất)';
$_['text_model_asc']    = 'Thương hiệu (A - Z)';
$_['text_model_desc']   = 'Thương hiệu (Z - A)';
$_['text_limit']        = 'Xem:';