<?php
// Text
$_['text_upload']    = 'File upload thành công!';

// Error
$_['error_filename'] = 'Tên file dài từ 3 đến 64 ký tự!';
$_['error_filetype'] = 'File không hợp lệ!';
$_['error_upload']   = 'Đã yêu cầu upload!';