<?php
// Text
$_['text_subject']  = 'Bạn đã nhận được một mã quà tặng từ %s';
$_['text_greeting'] = 'Chúc mừng, Bạn nhận được một mã quà tặng trị gía %s';
$_['text_from']     = 'Mã quà tặng được gửi đến từ %s';
$_['text_message']  = 'Cùng với thông điệp';
$_['text_redeem']   = 'Để sử dụng mã quà tặng này, bạn hãy lưu lại mã <b>%s</b> sau đó click vào link bên dưới và mua sản phẩm mà bạn muốn với mã này. Bạn cũng có thể nhập mã này khi thanh toán bất kỳ đơn hàng nào.';
$_['text_footer']   = 'Nếu bạn có bất kỳ câu hỏi nào hãy reply email này nhé.';