<?php
// Text
$_['text_subject']  = '%s - yêu cầu reset mật khẩu';
$_['text_greeting'] = 'Mật khẩu mới đã đưọc request cho %s tài khoản khách hàng.';
$_['text_change']   = 'Để reset mật khẩu bạn click vào link bên dưới:';
$_['text_ip']       = 'IP dùng để tạo request:';