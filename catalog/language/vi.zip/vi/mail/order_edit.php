<?php
// Text
$_['text_subject']      = '%s - Cập nhật đơn hàng %s';
$_['text_order_id']     = 'Mã đơn hàng:';
$_['text_date_added']   = 'Ngày tạo:';
$_['text_order_status'] = 'Đơn hàng của bạn được update trạng thái:';
$_['text_comment']      = 'Comment cho đơn hàng của bạn:';
$_['text_link']         = 'Để xem đơn hàng bạn click vào link bên dưới:';
$_['text_footer']       = 'Nếu bạn có bất kỳ câu hỏi nào hãy reply email này nhé.';