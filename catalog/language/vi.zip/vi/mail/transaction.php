<?php
// Text
$_['text_subject']  = '%s - Thanh toán liên kết';
$_['text_received'] = 'Chúc mừng! Bạn nhận được một liên kết thanh toán %s thanh toán liên kết.';
$_['text_amount']   = 'Bạn đã nhận được:';
$_['text_total']    = 'Tổng số tiền phải thanh toán của bạn là:';