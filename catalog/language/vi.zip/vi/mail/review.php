<?php
// Text
$_['text_subject']  = '%s - Đánh gía sản phẩm';
$_['text_waiting']  = 'Bạn có một sản phẩm mới đang chờ đánh gía.';
$_['text_product']  = 'Sản phẩm: %s';
$_['text_reviewer'] = 'Người đánh gía: %s';
$_['text_rating']   = 'Đánh gía: %s';
$_['text_review']   = 'Nội dung đánh gía:';