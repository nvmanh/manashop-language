<?php
// Text
$_['text_subject']        = '%s - Chiến dịch liên kết';
$_['text_welcome']        = 'Cảm ơn bạn đã tham gia chương trình %s Affiliate Program!';
$_['text_login']          = 'Tài khoản của bạn đã được tạo và bạn có thể đăng nhập bằng e-mail và mật khẩu bằng cách truy cập vào website hoặc theo đường link bên dưới:';
$_['text_approval']       = 'Tài khoản của bạn cần được cấp phép trước khi đăng nhập. Ngay khi tài khoản được tặng bạn có thể đăng nhập bằng e-mail và mật khẩu bằng cách truy cập vào website hoặc theo đường link bên dưới:';
$_['text_service']        = 'Sau khi đăng nhập, bạn có thể theo dõi mã sản phẩm, giao dịch, mua bán và chỉnh sửa thông tin tài khoản.';
$_['text_thanks']         = 'Cảm ơn,';
$_['text_new_affiliate']  = 'Chiến dịch mới';
$_['text_signup']         = 'Đã đăng ký chiến dịch:';
$_['text_website']        = 'Web Site:';
$_['text_customer_group'] = 'Nhóm khách hàng:';
$_['text_firstname']      = 'Họ và tên đệm:';
$_['text_lastname']       = 'Tên:';
$_['text_company']        = 'Công ty:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = 'Số ĐT:';