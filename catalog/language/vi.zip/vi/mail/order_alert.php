<?php
// Text
$_['text_subject']      = '%s - Đơn hàng %s';
$_['text_received']     = 'Bạn nhận được một đơn hàng.';
$_['text_order_id']     = 'Mã đơn hàng:';
$_['text_date_added']   = 'Ngày tạo:';
$_['text_order_status'] = 'Trạng thái:';
$_['text_product']      = 'Sản phẩm';
$_['text_total']        = 'Tổng';
$_['text_comment']      = 'Comment cho đơn hàng:';
