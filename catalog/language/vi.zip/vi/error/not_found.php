<?php
// Heading
$_['heading_title'] = 'Trang mà bạn tìm không tông tại!';

// Text
$_['text_error']    = 'Trang mà bạn tìm không tông tại.';